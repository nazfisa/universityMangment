package com.example.tufteam.controller;

import com.example.tufteam.dto.DepartmentDto;
import com.example.tufteam.entity.Department;
import com.example.tufteam.entity.Student;
import com.example.tufteam.service.DepartmentService;
import com.example.tufteam.service.StudentService;
import com.example.tufteam.service.SubjectService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Controller
@RequestMapping("/department")
public class DepartmentController {

    private final DepartmentService departmentService;
    private final SubjectService subjectService;
    private final StudentService studentService;

    public DepartmentController(DepartmentService departmentService, SubjectService subjectService, StudentService studentService) {
        this.departmentService = departmentService;
        this.subjectService = subjectService;
        this.studentService = studentService;
    }

    @GetMapping("/getAll")
    public String getAllDepartment(Model model) {
        List<Department> departmentList = departmentService.getAllDepartment();
        List<DepartmentDto> departmentDtoList = this.departmentListToDepartmentDtoList(departmentList);
        model.addAttribute("departmentDtoList", departmentDtoList);
        return "department/departmentList";
    }

    @GetMapping("/add")
    public String getAddPage(Model model) {
        model.addAttribute("departmentDto", new DepartmentDto());
        model.addAttribute("subjectListDto", subjectService.getAllSubjectDto());
        model.addAttribute("studentListDto", studentService.getAllStudentDto());
//        model.addAttribute("studentListDto", studentService.getAllStudentDto());
        return "department/add";
    }

    @PostMapping("/save")
    public String saveDepartment(@ModelAttribute DepartmentDto departmentDto) {
    Department department=new Department();
    departmentService.saveDepartment(departmentDto);
        return "redirect:/department/getAll";
    }

    /*------------------------------Helper Method------------------------------*/
    private List<DepartmentDto> departmentListToDepartmentDtoList(List<Department> departmentList) {
        ModelMapper modelMapper = new ModelMapper();
        List<DepartmentDto> departmentDtoList = new ArrayList<>();
        for (Department department : departmentList) {
            DepartmentDto departmentDto = new DepartmentDto();
//            BeanUtils.copyProperties(department, departmentDto);

            modelMapper.map(department, departmentDto);
            System.out.println("dto--> "+departmentDto); System.out.println("Entity -->"+department);
            departmentDtoList.add(departmentDto);
        }
        return departmentDtoList;
    }

}
