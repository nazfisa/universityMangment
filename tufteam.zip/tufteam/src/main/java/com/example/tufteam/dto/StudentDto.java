package com.example.tufteam.dto;


import lombok.Data;
import java.util.List;

@Data
public class StudentDto {
    private long StudentId;
    private String name;
    private int age;
    private String gender;
    private boolean enable = true;
}
