package com.example.tufteam.repository;

import com.example.tufteam.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface DepartmentRepo extends JpaRepository<Department,Long> {
    @Query
    List<Department> getAllByEnableTrue();
}
