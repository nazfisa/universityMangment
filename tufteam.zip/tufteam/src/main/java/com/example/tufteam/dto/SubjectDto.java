package com.example.tufteam.dto;

import lombok.Data;

@Data
public class SubjectDto {
    private long subjectId;
    private String subjectName;
    private StudentDto studentdto;
}
