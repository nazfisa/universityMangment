package com.example.tufteam.repository;

import com.example.tufteam.entity.Department;
import com.example.tufteam.entity.Student;
import com.example.tufteam.entity.Subject;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SubjectRepo extends JpaRepository<Subject,Long> {

    boolean existsBySubjectName(String subjectName);

//    List<Subject> findAllByStudent(Student student);

//    List<Subject> getAllByDepartment(Department department);
}
