package com.example.tufteam.controller;

import com.example.tufteam.dto.DepartmentDto;
import com.example.tufteam.dto.StudentDto;
import com.example.tufteam.dto.SubjectDto;
import com.example.tufteam.entity.Department;
import com.example.tufteam.entity.Student;
import com.example.tufteam.entity.Subject;
import com.example.tufteam.service.DepartmentService;
import com.example.tufteam.service.StudentService;
import com.example.tufteam.service.SubjectService;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/student")
public class StudentController {

    private final StudentService studentService;
    private final DepartmentService departmentService;
    private final SubjectService subjectService;

    public StudentController(StudentService studentService, DepartmentService departmentService, SubjectService subjectService) {
        this.studentService = studentService;
        this.departmentService = departmentService;
        this.subjectService = subjectService;
    }

    @GetMapping("/getAllStudent")
    public String getAllStudent(Model model) {
        List<Student> studentList = studentService.getAllStudent();
        List<StudentDto> studentDtoList = this.studentListToStudentDtoList(studentList);
        model.addAttribute("studentDtoList", studentDtoList);
        return "student/studentList";
    }


    @GetMapping("/add")
    public String getAddPage(Model model) {
        model.addAttribute("studentDto", new StudentDto());
        model.addAttribute("departmentListDto",
                this.departmentListToDepartmentDtoList(departmentService.getAllDepartment()));
        model.addAttribute("genderList", this.genderList());

        model.addAttribute("subjectListDto",this.getSubjectDtoList(subjectService.getAllSubject()));
        return "student/add";
    }


    @PostMapping("/save")
    public String saveStudent(@ModelAttribute StudentDto studentDto) {
        Student student = new Student();
        BeanUtils.copyProperties(studentDto, student);
        studentService.saveStudent(student);
        return "redirect:/student/getAllStudent";
    }

    @GetMapping("/update/{studentId}")
    public String updateStudent(@PathVariable(name = "studentId") long studentId, Model model) {
        StudentDto studentDto = new StudentDto();
        Student student=studentService.getStudentById(studentId);
        BeanUtils.copyProperties(student, studentDto);
        model.addAttribute("studentDto", studentDto);

        model.addAttribute("departmentListDto",
                this.departmentListToDepartmentDtoList(departmentService.getAllDepartment()));
        model.addAttribute("genderList", this.genderList());
        return "student/add";
    }
    @GetMapping("/delete/{studentId}")
    public String deleteStudent(@PathVariable(name = "studentId") long studentId) {
        Student student=studentService.getStudentById(studentId);
        student.setEnable(false);
        studentService.saveStudent(student);
        return "redirect:/student/getAllStudent";
    }


    /*---------------------------------Helper Method---------------------------------------*/
    private List<StudentDto> studentListToStudentDtoList(List<Student> studentList) {
        List<StudentDto> studentDtoList = new ArrayList<>();
        for (Student student : studentList) {
            StudentDto studentDto = new StudentDto();
            BeanUtils.copyProperties(student, studentDto);

            studentDtoList.add(studentDto);
        }
        return studentDtoList;
    }

//    private DepartmentDto getDepartmentDto(Student student) {
//        DepartmentDto departmentDto = new DepartmentDto();
//        BeanUtils.copyProperties(student.getDepartment(), departmentDto);
//        return departmentDto;
//    }

    private List<String> genderList() {
        List<String> genderList = new ArrayList<>();
        genderList.add("Male");
        genderList.add("Female");
        return genderList;
    }

    private List<DepartmentDto> departmentListToDepartmentDtoList(List<Department> departmentList) {
        List<DepartmentDto> departmentDtoList = new ArrayList<>();
        for (Department department : departmentList) {
            DepartmentDto departmentDto = new DepartmentDto();
            BeanUtils.copyProperties(department, departmentDto);
            departmentDtoList.add(departmentDto);
        }
        return departmentDtoList;
    }

    private List<SubjectDto> getSubjectDtoList(List<Subject> subjectList) {
        List<SubjectDto> subjectDtoList = new ArrayList<>();
        for (Subject subject : subjectList) {
           SubjectDto subjectDto=new SubjectDto();
            BeanUtils.copyProperties(subject, subjectDto);
            subjectDtoList.add(subjectDto);
        }
        return subjectDtoList;
    }
}
