package com.example.tufteam.dto;

import lombok.Data;

import java.util.List;
import java.util.Set;

@Data
public class DepartmentDto {
    private long departmentId;
    private String departmentName;
    private String departmentCode;
    private boolean enable = true;
//    private List<Long> studentIdList;
//    private List<Long> subjectIdList;

    private Set<StudentDto> students;
    private Set<SubjectDto> subjectList;

}
