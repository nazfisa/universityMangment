package com.example.tufteam.init;

import com.example.tufteam.entity.Subject;
import com.example.tufteam.repository.SubjectRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class DataInitializer implements CommandLineRunner {
    @Autowired
    SubjectRepo subjectRepo;

    @Override
    public void run(String... args) throws Exception {
        Stream.of("Bangla", "Chemistry", "Biology","Math","English","Phy")
                .filter(subName -> !subjectRepo.existsBySubjectName(subName))
                .map(s -> {
                    Subject subject = new Subject();
                    subject.setSubjectName(s);
                    subjectRepo.save(subject);
                    return subject;
                }).forEach(System.out::println);
        }
}
