package com.example.tufteam.service;

import com.example.tufteam.dto.SubjectDto;
import com.example.tufteam.entity.Student;
import com.example.tufteam.entity.Subject;
import com.example.tufteam.repository.SubjectRepo;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SubjectService {
private final SubjectRepo subjectRepo;

    public SubjectService(SubjectRepo subjectRepo) {
        this.subjectRepo = subjectRepo;
    }

    public List<Subject> getAllSubject(){
        return subjectRepo.findAll();
    }

    public List<SubjectDto> getAllSubjectDto(){
        List<SubjectDto> subjectDtos = new ArrayList<>();
        subjectRepo.findAll().stream().forEach(subject -> {
            SubjectDto subjectDto = new SubjectDto();
            BeanUtils.copyProperties(subject, subjectDto);
            subjectDtos.add(subjectDto);
        });
        return subjectDtos;
    }

    public void saveSubject(Subject subject){
        subjectRepo.save(subject);
    }

    public Subject getSubjectById(long subjectId) {
    return subjectRepo.getOne(subjectId);
    }

//    public List<Subject> getAllOfStudent(Student student) {
//        return subjectRepo.findAllByStudent(student);
//    }
}
