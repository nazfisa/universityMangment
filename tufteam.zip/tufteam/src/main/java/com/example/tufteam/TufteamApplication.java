package com.example.tufteam;

import com.example.tufteam.init.DataInitializer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TufteamApplication {

    public static void main(String[] args) {
        SpringApplication.run(new Class[]{TufteamApplication.class, DataInitializer.class}, args);
    }
}
