package com.example.tufteam.service;

import com.example.tufteam.dto.StudentDto;
import com.example.tufteam.dto.SubjectDto;
import com.example.tufteam.entity.Student;
import com.example.tufteam.repository.StudentRepos;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class StudentService {
    private final StudentRepos studentRepo;

    public StudentService(StudentRepos studentRepo) {
        this.studentRepo = studentRepo;
    }

    public List<Student> getAllStudent() {
        return studentRepo.getAllByEnableTrue();
    }

    public List<StudentDto> getAllStudentDto(){
        List<StudentDto> studentDtos = new ArrayList<>();
        studentRepo.findAll().stream().forEach(student -> {
            StudentDto studentDto = new StudentDto();
            BeanUtils.copyProperties(student, studentDto);
            studentDtos.add(studentDto);
        });
        return studentDtos;
    }

    public Student saveStudent(Student student) {
        return studentRepo.save(student);
    }

    public Student getStudentById(long studentId) {
        Optional<Student> optionalStudent = studentRepo.findById(studentId);
        if (optionalStudent.isEmpty()) {
            throw new RuntimeException("Student Not Find By this Id");
        } else {
            return optionalStudent.get();
        }
    }
}
