package com.example.tufteam.service;

import com.example.tufteam.dto.DepartmentDto;
import com.example.tufteam.entity.Department;
import com.example.tufteam.entity.Student;
import com.example.tufteam.entity.Subject;
import com.example.tufteam.repository.DepartmentRepo;
import com.example.tufteam.repository.StudentRepos;
import com.example.tufteam.repository.SubjectRepo;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class DepartmentService {

    private final StudentRepos studentRepo;
    private final SubjectRepo subjectRepo;
    private final DepartmentRepo departmentRepo;

    public DepartmentService(StudentRepos studentRepo, SubjectRepo subjectRepo, DepartmentRepo departmentRepo) {
        this.studentRepo = studentRepo;
        this.subjectRepo = subjectRepo;
        this.departmentRepo = departmentRepo;
    }

    public List<Department> getAllDepartment() {
        return departmentRepo.findAll();
    }

    public Department getDepartmentById(long id){
        return departmentRepo.getOne(id);
    }

    public void saveDepartment(DepartmentDto departmentDto) {
        Optional<Department> departmentOptional = departmentRepo.findById(departmentDto.getDepartmentId());
        List<Subject> subjects = null;
        List<Student> studentsTemp = null;
        Department department = null;
        if (departmentOptional.isEmpty()) {
            department = new Department();
            BeanUtils.copyProperties(departmentDto, department);
            subjects = new ArrayList<>();
            studentsTemp = new ArrayList<>();
        } else {
            department = departmentOptional.get();
            subjects = new ArrayList<>(department.getSubjectList());
            studentsTemp = new ArrayList<>(department.getStudents());
        }

        Set<Subject> finalSubjects = new HashSet<>(subjects);
        Set<Student> finalStudents = new HashSet<>(studentsTemp);

        departmentDto.getSubjectIdList().forEach(aLong -> {
            Subject subject = subjectRepo.getOne(aLong);
            finalSubjects.add(subject);
        });
        department.setSubjectList(finalSubjects);

        departmentDto.getStudentIdList().forEach(aLong -> {
            Student stu = studentRepo.getOne(aLong);
            finalStudents.add(stu);
        });
        department.setStudents(finalStudents);

        departmentRepo.save(department);
    }
}
