package com.example.tufteam.repository;


import com.example.tufteam.entity.Department;
import com.example.tufteam.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface StudentRepos extends JpaRepository<Student,Long> {

    List<Student> getAllByEnableTrue();

//    List<Student> getAllByDepartment(Department department);

}
